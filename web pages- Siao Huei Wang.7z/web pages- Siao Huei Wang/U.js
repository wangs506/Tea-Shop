﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

//--- Common
var isHorizontal=1;
var smColumns=1;
var smOrientation=0;
var smViewType=0;
var dmRTL=0;
var pressedItem=-2;
var itemCursor="default";
var itemTarget="_self";
var statusString="link";
var blankImage="data-samples/images/blank.gif";

//--- Dimensions
var menuWidth="";
var menuHeight="";
var smWidth="";
var smHeight="";

//--- Positioning
var absolutePos=0;
var posX="0";
var posY="0";
var topDX=0;
var topDY=3;
var DX=0;
var DY=0;

//--- Font
var fontStyle="normal 13px Tahoma";
var fontColor=["#000000","#FFFFFF"];
var fontDecoration=["none","none"];
var fontColorDisabled="#AAAAAA";

//--- Appearance
var menuBackColor="#FCEEB0";
var menuBackImage="";
var menuBackRepeat="repeat";
var menuBorderColor="#C0AF62";
var menuBorderWidth=1;
var menuBorderStyle="solid";

//--- Item Appearance
var itemBackColor=["#FCEEB0","#65BDDC"];
var itemBackImage=["",""];
var itemBorderWidth=1;
var itemBorderColor=["#FCEEB0","#4C99AB"];
var itemBorderStyle=["solid","solid"];
var itemSpacing=3;
var itemPadding="3";
var itemAlignTop="left";
var itemAlign="left";
var subMenuAlign="";

//--- Icons
var iconTopWidth=16;
var iconTopHeight=16;
var iconWidth=16;
var iconHeight=16;
var arrowWidth=8;
var arrowHeight=16;
var arrowImageMain=["",""];
var arrowImageSub=["arrow_sub8.gif","arrow_sub9.gif"];

//--- Separators
var separatorImage="";
var separatorWidth="100%";
var separatorHeight="3";
var separatorAlignment="left";
var separatorVImage="";
var separatorVWidth="3";
var separatorVHeight="100%";

//--- Floatable Menu
var floatable=0;
var floatIterations=6;
var floatableX=1;
var floatableY=1;

//--- Movable Menu
var movable=0;
var moveWidth=12;
var moveHeight=20;
var moveColor="#AA0000";
var moveImage="";
var moveCursor="default";
var smMovable=0;
var closeBtnW=15;
var closeBtnH=15;
var closeBtn="";

//--- Transitional Effects & Filters
var transparency="90";
var transition=32;
var transOptions="";
var transDuration=350;
var transDuration2=200;
var shadowLen=4;
var shadowColor="#D6D6D6";
var shadowTop=1;

//--- CSS Support (CSS-based Menu)
var cssStyle=0;
var cssSubmenu="";
var cssItem=["",""];
var cssItemText=["",""];

//--- Advanced
var dmObjectsCheck=0;
var saveNavigationPath=1;
var showByClick=0;
var noWrap=1;
var pathPrefix_img="data-samples/images/";
var pathPrefix_link="data-samples/";
var smShowPause=200;
var smHidePause=1000;
var smSmartScroll=1;
var topSmartScroll=0;
var smHideOnClick=1;
var dm_writeAll=0;

//--- AJAX-like Technology
var dmAJAX=0;
var dmAJAXCount=0;

//--- Dynamic Menu
var dynamic=0;

//--- Keystrokes Support
var keystrokes=1;
var dm_focus=1;
var dm_actKey=113;

var itemStyles = [
    ["fontStyle=bold 11px Verdana","fontColor=#FDFDFD,#FDFDFD","itemBorderWidth=1","itemBorderStyle=solid,solid","itemBackColor=#29B3A2,#29B3A2","itemBorderColor=#1F877A,#1F877A",],
    ["itemBackImage=blank.gif,itembacko.gif","fontColor=#000000,#000000","itemBorderWidth=0","itemBackColor=transparent,#3CD3C1"],
];
var menuStyles = [
    ["menuBackImage=subm_back.gif"],
    [],
];

var menuItems = [

    ["Home","testlink.htm", "icon1.gif", "icon1o.gif"],
    ["Product Info","", "icon1.gif", "icon1o.gif"],
        ["|Features","testlink.htm", "icon2.gif", "icon2o.gif"],
        ["|Installation","testlink.htm", "icon2.gif", "icon2o.gif"],
            ["||Description of Files","testlink.htm", "icon5.gif", "icon5o.gif", , , "1", "0", ],
            ["||How To Setup","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
        ["|Dynamic Functions","testlink.htm", "icon2.gif", "icon2o.gif"],
        ["|Parameters Info","testlink.htm", "icon2.gif", "icon2o.gif"],
        ["|Supported Browsers","testlink.htm", "icon2.gif", "icon2o.gif"],
            ["||Windows OS","", "icon3.gif", , , , "0", "0", ],
            ["||Firefox","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||Internet Explorer","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||Netscape Navigator","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||Mozilla","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||Opera","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||MAC OS","", "icon3.gif", , , , "0"],
            ["||Firefox","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||Internet Explorer","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||Safari","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||Unix/Linux OS","", "icon3.gif", , , , "0"],
            ["||Firefox","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
            ["||Konqueror","testlink.htm", "icon5.gif", "icon5o.gif", , , "1"],
    ["Contact Us","testlink.htm", "icon1.gif", "icon1o.gif"],
];

dm_init();